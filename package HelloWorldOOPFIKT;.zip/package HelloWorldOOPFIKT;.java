package HelloWorldOOPFIKT;

public class HelloWorld {
	public static void main(String[] args) {

		System.out.println("Hellow World OOP Fikt");

	}
}
